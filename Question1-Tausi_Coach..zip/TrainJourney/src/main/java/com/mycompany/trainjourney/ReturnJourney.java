/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trainjourney;

/**
 *
 * @author ariihopaul
 */
public class ReturnJourney {
    
    public static void main(String[] args) {
        int totalDistance = 10000;
        int speed = 250; 
        int refuelDistance = 200; 
        int stopTime = 5; 

        int refuelStops = totalDistance / refuelDistance;

        if (totalDistance % refuelDistance == 0) {
            refuelStops--;
        }
        int travelTime = totalDistance / speed; 

        double totalStopTime = refuelStops * (stopTime / 60.0); 

        double totalTime = travelTime + totalStopTime;

        System.out.println("Total time taken for return journey: " + totalTime + " hours");
    }
}